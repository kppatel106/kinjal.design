# Portfolio Website

## Overview

This is a modern, responsive portfolio website for a UI/UX designer named Kinjal Patel. The application showcases design work, skills, services, and provides a contact form for potential clients. Built with React, TypeScript, and a Node.js/Express backend, the site features a dark theme design with smooth animations and professional presentation.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Animations**: Framer Motion for smooth page transitions and interactions
- **Forms**: React Hook Form with Zod validation
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints
- **Development**: tsx for TypeScript execution in development
- **Production**: esbuild for server bundling

### Database Layer
- **ORM**: Drizzle ORM with Zod integration for type safety
- **Database**: PostgreSQL with live database connection
- **Connection**: Neon Database serverless driver
- **Storage**: DatabaseStorage implementation with full CRUD operations
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Frontend Components
- **Navigation**: Responsive navigation with smooth scrolling
- **Hero Section**: Animated landing area with profile image and call-to-action
- **About**: Personal introduction with statistics and expertise areas
- **Skills**: Animated skill bars and tool proficiency indicators
- **Services**: Service offerings with detailed feature lists
- **Portfolio**: Project showcase with filtering and modal views
- **Testimonials**: Client feedback with star ratings
- **Contact**: Contact form with budget selection and validation
- **Footer**: Social links and closing information
- **Floating Buttons**: Persistent hire-me and back-to-top buttons

### Backend Services
- **Contact Form Handler**: Processes and stores contact form submissions
- **Admin Authentication**: Secure login system with session management
- **Content Management API**: Full CRUD operations for website content
- **Media Management API**: File upload and management system
- **Contact Messages API**: Retrieves stored messages (admin functionality)
- **Static File Serving**: Serves the built React application and uploaded media
- **Development Server**: Vite integration for hot module replacement

### Database Schema
- **Users Table**: Admin authentication with username, password, and admin flag
- **Contact Messages Table**: Stores form submissions with timestamps
- **Site Content Table**: Dynamic content management for all website sections
- **Media Assets Table**: File uploads with metadata and categorization

## Data Flow

1. **Client Interaction**: User interacts with React components
2. **Form Submission**: Contact form data validated with Zod schemas
3. **API Request**: TanStack Query sends validated data to Express endpoints
4. **Data Processing**: Express routes handle business logic and validation
5. **Database Operations**: Drizzle ORM manages data persistence
6. **Response Handling**: Success/error responses sent back to client
7. **UI Updates**: React components update based on API responses with toast notifications

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React ecosystem with TypeScript support
- **Component Library**: Radix UI primitives for accessibility
- **Animation**: Framer Motion for professional animations
- **Icons**: Lucide React for consistent iconography
- **Utilities**: clsx and tailwind-merge for conditional styling
- **Date Handling**: date-fns for timestamp formatting

### Backend Dependencies
- **Database**: Neon Database serverless PostgreSQL
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod for runtime type checking
- **Development**: tsx for TypeScript execution
- **Session Management**: connect-pg-simple (prepared for future auth)

### Development Tools
- **Build Tools**: Vite for frontend, esbuild for backend
- **CSS Processing**: Tailwind CSS with PostCSS
- **Type Checking**: TypeScript with strict configuration
- **Error Handling**: Replit runtime error overlay

## Deployment Strategy

### Development Environment
- **Package Manager**: npm with lockfile for consistency
- **Development Server**: Concurrent frontend (Vite) and backend (tsx) processes
- **Hot Reloading**: Vite HMR for instant feedback during development
- **Environment**: Replit environment with PostgreSQL module

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: esbuild bundles server code with external dependencies
- **Static Serving**: Express serves built React application
- **Database**: Environment variable-based PostgreSQL connection

### Configuration
- **Port**: Application runs on port 5000 with external port 80
- **Build Command**: `npm run build` - builds both frontend and backend
- **Start Command**: `npm run start` - runs production server
- **Database Push**: `npm run db:push` - applies schema changes

Changelog:
- June 29, 2025. Initial setup
- June 29, 2025. Added PostgreSQL database integration with live database connection
- June 29, 2025. Enhanced About section layout and updated hero image
- June 29, 2025. Built complete admin dashboard with authentication, content management, and media uploads

## Admin Dashboard

### Access
- **URL**: `/admin/login`
- **Username**: `admin`
- **Password**: `admin123`

### Features
- **Content Management**: Edit all website content including hero, about, skills, services sections
- **Media Management**: Upload and manage images, icons, and other assets
- **Contact Messages**: View and manage form submissions
- **Session Management**: Secure login with 24-hour session timeout

### Usage Instructions
1. Navigate to `/admin/login` and sign in with credentials
2. Use the Overview tab to see dashboard statistics
3. Content tab allows editing website sections as JSON
4. Media tab supports image uploads up to 5MB
5. Messages tab displays contact form submissions

## User Preferences

Preferred communication style: Simple, everyday language.