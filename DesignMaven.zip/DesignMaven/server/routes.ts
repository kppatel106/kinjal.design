import type { Express, Request, Response, NextFunction } from "express";
import path from "path";
import { createServer, type Server } from "http";
import { z } from "zod";
import session from "express-session";
import bcrypt from "bcryptjs";
import multer from "multer";
import { storage } from "./storage";
import { insertContactMessageSchema, loginSchema, insertSiteContentSchema, updateSiteContentSchema, insertMediaAssetSchema } from "@shared/schema";

// Session configuration
declare module 'express-session' {
  interface SessionData {
    userId?: number;
    isAdmin?: boolean;
  }
}

// Authentication middleware
function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: "Authentication required" });
  }
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).json({ success: false, message: "Admin access required" });
  }
  next();
}

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/') || file.mimetype.startsWith('icon/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  }));

  // Serve uploaded files statically
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
  });
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      
      res.json({ 
        success: true, 
        message: "Message sent successfully!",
        id: message.id 
      });
    } catch (error) {
      console.error("Contact form error:", error);
      
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Invalid form data",
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Failed to send message. Please try again." 
        });
      }
    }
  });

  // Authentication endpoints
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || !user.isAdmin) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }
      
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }
      
      req.session.userId = user.id;
      req.session.isAdmin = true;
      
      res.json({ 
        success: true, 
        message: "Login successful",
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ success: false, message: "Login failed" });
    }
  });

  app.post("/api/admin/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ success: false, message: "Logout failed" });
      }
      res.json({ success: true, message: "Logout successful" });
    });
  });

  app.get("/api/admin/me", requireAdmin, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }
      res.json({ 
        success: true, 
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch user" });
    }
  });

  // Content management endpoints
  app.get("/api/admin/content", requireAdmin, async (req, res) => {
    try {
      const content = await storage.getAllSiteContent();
      res.json({ success: true, content });
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ success: false, message: "Failed to fetch content" });
    }
  });

  app.get("/api/admin/content/:section", requireAdmin, async (req, res) => {
    try {
      const { section } = req.params;
      const content = await storage.getSiteContent(section);
      res.json({ success: true, content });
    } catch (error) {
      console.error("Error fetching content section:", error);
      res.status(500).json({ success: false, message: "Failed to fetch content section" });
    }
  });

  app.post("/api/admin/content", requireAdmin, async (req, res) => {
    try {
      const contentData = insertSiteContentSchema.parse(req.body);
      const content = await storage.upsertSiteContent(contentData);
      res.json({ success: true, content });
    } catch (error) {
      console.error("Error creating/updating content:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ success: false, message: "Invalid content data", errors: error.errors });
      } else {
        res.status(500).json({ success: false, message: "Failed to save content" });
      }
    }
  });

  app.put("/api/admin/content/:section", requireAdmin, async (req, res) => {
    try {
      const { section } = req.params;
      const contentData = updateSiteContentSchema.parse(req.body);
      const content = await storage.updateSiteContent(section, contentData);
      res.json({ success: true, content });
    } catch (error) {
      console.error("Error updating content:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ success: false, message: "Invalid content data", errors: error.errors });
      } else {
        res.status(500).json({ success: false, message: "Failed to update content" });
      }
    }
  });

  // Media management endpoints
  app.get("/api/admin/media", requireAdmin, async (req, res) => {
    try {
      const { category } = req.query;
      const assets = category 
        ? await storage.getMediaAssetsByCategory(category as string)
        : await storage.getMediaAssets();
      res.json({ success: true, assets });
    } catch (error) {
      console.error("Error fetching media:", error);
      res.status(500).json({ success: false, message: "Failed to fetch media" });
    }
  });

  app.post("/api/admin/media", requireAdmin, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: "No file uploaded" });
      }

      const { name, type, altText, category } = req.body;
      const assetData = insertMediaAssetSchema.parse({
        name: name || req.file.originalname,
        type: type || 'image',
        url: `/uploads/${req.file.filename}`,
        altText,
        category,
      });

      const asset = await storage.createMediaAsset(assetData);
      res.json({ success: true, asset });
    } catch (error) {
      console.error("Error uploading media:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ success: false, message: "Invalid media data", errors: error.errors });
      } else {
        res.status(500).json({ success: false, message: "Failed to upload media" });
      }
    }
  });

  app.put("/api/admin/media/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updateData = req.body;
      const asset = await storage.updateMediaAsset(parseInt(id), updateData);
      res.json({ success: true, asset });
    } catch (error) {
      console.error("Error updating media:", error);
      res.status(500).json({ success: false, message: "Failed to update media" });
    }
  });

  app.delete("/api/admin/media/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteMediaAsset(parseInt(id));
      res.json({ success: true, message: "Media deleted successfully" });
    } catch (error) {
      console.error("Error deleting media:", error);
      res.status(500).json({ success: false, message: "Failed to delete media" });
    }
  });

  // Create admin user (temporary endpoint for setup)
  app.post("/api/admin/create-admin", async (req, res) => {
    try {
      // Check if admin already exists
      const existingAdmin = await storage.getUserByUsername("admin");
      if (existingAdmin) {
        return res.json({ success: true, message: "Admin user already exists" });
      }

      const hashedPassword = await bcrypt.hash("admin123", 10);
      const adminUser = await storage.createUser({
        username: "admin",
        password: hashedPassword,
      });
      
      res.json({ 
        success: true, 
        message: "Admin user created successfully",
        credentials: {
          username: "admin",
          password: "admin123"
        }
      });
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ success: false, message: "Failed to create admin user" });
    }
  });

  // Get all contact messages (admin only)
  app.get("/api/admin/contact-messages", requireAdmin, async (req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json({ success: true, messages });
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch messages" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
