import { users, contactMessages, siteContent, mediaAssets, type User, type InsertUser, type ContactMessage, type InsertContactMessage, type SiteContent, type InsertSiteContent, type UpdateSiteContent, type MediaAsset, type InsertMediaAsset } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact messages
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  
  // Content management
  getSiteContent(section: string): Promise<SiteContent | undefined>;
  getAllSiteContent(): Promise<SiteContent[]>;
  upsertSiteContent(content: InsertSiteContent): Promise<SiteContent>;
  updateSiteContent(section: string, content: UpdateSiteContent): Promise<SiteContent>;
  
  // Media assets
  getMediaAssets(): Promise<MediaAsset[]>;
  getMediaAssetsByCategory(category: string): Promise<MediaAsset[]>;
  createMediaAsset(asset: InsertMediaAsset): Promise<MediaAsset>;
  updateMediaAsset(id: number, asset: Partial<InsertMediaAsset>): Promise<MediaAsset>;
  deleteMediaAsset(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contactMessages: Map<number, ContactMessage>;
  private currentUserId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.contactMessages = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentMessageId++;
    const message: ContactMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Contact messages
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const [message] = await db
      .insert(contactMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return await db
      .select()
      .from(contactMessages)
      .orderBy(contactMessages.createdAt);
  }

  // Content management
  async getSiteContent(section: string): Promise<SiteContent | undefined> {
    const [content] = await db
      .select()
      .from(siteContent)
      .where(eq(siteContent.section, section));
    return content || undefined;
  }

  async getAllSiteContent(): Promise<SiteContent[]> {
    return await db.select().from(siteContent);
  }

  async upsertSiteContent(content: InsertSiteContent): Promise<SiteContent> {
    const [result] = await db
      .insert(siteContent)
      .values(content)
      .onConflictDoUpdate({
        target: siteContent.section,
        set: {
          content: content.content,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  async updateSiteContent(section: string, content: UpdateSiteContent): Promise<SiteContent> {
    const [result] = await db
      .update(siteContent)
      .set({
        ...content,
        updatedAt: new Date(),
      })
      .where(eq(siteContent.section, section))
      .returning();
    return result;
  }

  // Media assets
  async getMediaAssets(): Promise<MediaAsset[]> {
    return await db.select().from(mediaAssets).orderBy(mediaAssets.uploadedAt);
  }

  async getMediaAssetsByCategory(category: string): Promise<MediaAsset[]> {
    return await db
      .select()
      .from(mediaAssets)
      .where(eq(mediaAssets.category, category))
      .orderBy(mediaAssets.uploadedAt);
  }

  async createMediaAsset(asset: InsertMediaAsset): Promise<MediaAsset> {
    const [result] = await db
      .insert(mediaAssets)
      .values(asset)
      .returning();
    return result;
  }

  async updateMediaAsset(id: number, asset: Partial<InsertMediaAsset>): Promise<MediaAsset> {
    const [result] = await db
      .update(mediaAssets)
      .set(asset)
      .where(eq(mediaAssets.id, id))
      .returning();
    return result;
  }

  async deleteMediaAsset(id: number): Promise<void> {
    await db.delete(mediaAssets).where(eq(mediaAssets.id, id));
  }
}

export const storage = new DatabaseStorage();
