import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { 
  Settings, 
  FileText, 
  Image, 
  MessageSquare, 
  LogOut, 
  Upload,
  Edit,
  Trash2,
  Save,
  Plus
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  username: string;
}

interface SiteContent {
  id: number;
  section: string;
  content: any;
  updatedAt: string;
}

interface MediaAsset {
  id: number;
  name: string;
  type: string;
  url: string;
  altText?: string;
  category?: string;
  uploadedAt: string;
}

interface ContactMessage {
  id: number;
  name: string;
  email: string;
  budget: string;
  message: string;
  createdAt: string;
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [editingContent, setEditingContent] = useState<string | null>(null);
  const [contentForm, setContentForm] = useState<{ section: string; content: string }>({
    section: "",
    content: "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check authentication
  const { data: user, isLoading: userLoading } = useQuery<{ user: User }>({
    queryKey: ["/api/admin/me"],
    retry: false,
  });

  // Get all content
  const { data: contentData } = useQuery<{ content: SiteContent[] }>({
    queryKey: ["/api/admin/content"],
    enabled: !!user,
  });

  // Get media assets
  const { data: mediaData } = useQuery<{ assets: MediaAsset[] }>({
    queryKey: ["/api/admin/media"],
    enabled: !!user,
  });

  // Get contact messages
  const { data: messagesData } = useQuery<{ messages: ContactMessage[] }>({
    queryKey: ["/api/admin/contact-messages"],
    enabled: !!user,
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/logout"),
    onSuccess: () => {
      window.location.href = "/admin/login";
    },
  });

  // Content update mutation
  const updateContentMutation = useMutation({
    mutationFn: (data: { section: string; content: any }) =>
      apiRequest("POST", "/api/admin/content", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/content"] });
      setEditingContent(null);
      toast({
        title: "Success",
        description: "Content updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update content",
        variant: "destructive",
      });
    },
  });

  // Media upload mutation
  const uploadMediaMutation = useMutation({
    mutationFn: (formData: FormData) =>
      fetch("/api/admin/media", {
        method: "POST",
        body: formData,
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/media"] });
      toast({
        title: "Success",
        description: "Media uploaded successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload media",
        variant: "destructive",
      });
    },
  });

  if (userLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!user) {
    window.location.href = "/admin/login";
    return null;
  }

  const handleContentEdit = (section: string, content: any) => {
    setEditingContent(section);
    setContentForm({
      section,
      content: JSON.stringify(content, null, 2),
    });
  };

  const handleContentSave = () => {
    try {
      const parsedContent = JSON.parse(contentForm.content);
      updateContentMutation.mutate({
        section: contentForm.section,
        content: parsedContent,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid JSON format",
        variant: "destructive",
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("name", file.name);
    formData.append("type", "image");
    formData.append("category", "upload");

    uploadMediaMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800/50 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Settings className="w-8 h-8 text-blue-500" />
            <div>
              <h1 className="text-xl font-bold text-white">Portfolio Dashboard</h1>
              <p className="text-sm text-slate-400">Welcome back, {user.user.username}</p>
            </div>
          </div>
          <Button
            onClick={() => logoutMutation.mutate()}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50">
            <TabsTrigger value="overview" className="data-[state=active]:bg-slate-700">
              <Settings className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="content" className="data-[state=active]:bg-slate-700">
              <FileText className="w-4 h-4 mr-2" />
              Content
            </TabsTrigger>
            <TabsTrigger value="media" className="data-[state=active]:bg-slate-700">
              <Image className="w-4 h-4 mr-2" />
              Media
            </TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-slate-700">
              <MessageSquare className="w-4 h-4 mr-2" />
              Messages
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-blue-500" />
                    Content Sections
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">
                    {contentData?.content.length || 0}
                  </div>
                  <p className="text-slate-400">Managed sections</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Image className="w-5 h-5 mr-2 text-green-500" />
                    Media Assets
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">
                    {mediaData?.assets.length || 0}
                  </div>
                  <p className="text-slate-400">Uploaded files</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <MessageSquare className="w-5 h-5 mr-2 text-purple-500" />
                    Contact Messages
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">
                    {messagesData?.messages.length || 0}
                  </div>
                  <p className="text-slate-400">Total inquiries</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content" className="mt-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">Content Management</h2>
                <Button
                  onClick={() => {
                    setEditingContent("new");
                    setContentForm({ section: "", content: "{}" });
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Section
                </Button>
              </div>

              {editingContent && (
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">
                      {editingContent === "new" ? "Create New Section" : `Edit ${editingContent}`}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-slate-300">Section Name</Label>
                      <Input
                        value={contentForm.section}
                        onChange={(e) => setContentForm(prev => ({ ...prev, section: e.target.value }))}
                        className="bg-slate-700/50 border-slate-600 text-white"
                        placeholder="e.g., hero, about, skills"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-300">Content (JSON)</Label>
                      <Textarea
                        value={contentForm.content}
                        onChange={(e) => setContentForm(prev => ({ ...prev, content: e.target.value }))}
                        className="bg-slate-700/50 border-slate-600 text-white min-h-[200px] font-mono"
                        placeholder="Enter JSON content..."
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={handleContentSave} className="bg-green-600 hover:bg-green-700">
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                      <Button
                        onClick={() => setEditingContent(null)}
                        variant="outline"
                        className="border-slate-600 text-slate-300"
                      >
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid gap-4">
                {contentData?.content.map((item) => (
                  <Card key={item.id} className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-white">{item.section}</CardTitle>
                          <CardDescription>
                            Updated: {new Date(item.updatedAt).toLocaleDateString()}
                          </CardDescription>
                        </div>
                        <Button
                          onClick={() => handleContentEdit(item.section, item.content)}
                          size="sm"
                          variant="outline"
                          className="border-slate-600 text-slate-300"
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-slate-300 text-sm bg-slate-900/50 p-3 rounded-lg overflow-auto max-h-32">
                        {JSON.stringify(item.content, null, 2)}
                      </pre>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Media Management Tab */}
          <TabsContent value="media" className="mt-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">Media Management</h2>
                <div className="relative">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Image
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mediaData?.assets.map((asset) => (
                  <Card key={asset.id} className="bg-slate-800/50 border-slate-700">
                    <CardContent className="p-4">
                      <div className="aspect-video bg-slate-700 rounded-lg mb-3 overflow-hidden">
                        <img
                          src={asset.url}
                          alt={asset.altText || asset.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-medium text-white truncate">{asset.name}</h3>
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                            {asset.type}
                          </Badge>
                          {asset.category && (
                            <Badge variant="outline" className="border-slate-600 text-slate-400">
                              {asset.category}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-slate-400">
                          {new Date(asset.uploadedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="mt-6">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">Contact Messages</h2>
              
              <div className="space-y-4">
                {messagesData?.messages.map((message) => (
                  <Card key={message.id} className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-white">{message.name}</CardTitle>
                          <CardDescription>{message.email}</CardDescription>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-green-600">
                            {message.budget}
                          </Badge>
                          <p className="text-sm text-slate-400 mt-1">
                            {new Date(message.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-300">{message.message}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}