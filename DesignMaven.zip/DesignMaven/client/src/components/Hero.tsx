import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { scrollToSection } from '@/lib/utils';

import _1745305083061 from "@assets/1745305083061.jpeg";

const Hero = () => {
  const handleCTAClick = (section: string) => {
    scrollToSection(section);
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-16">
      {/* Background Animation */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-gray-900 to-indigo-900/20"></div>
        <div className="floating-orb"></div>
        <div className="floating-orb"></div>
        <div className="floating-orb"></div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          
          {/* Profile Image - Left Side */}
          <motion.div 
            className="lg:w-1/2 flex justify-center"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Glow effects */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full blur-xl opacity-30 animate-glow"></div>
              <div className="absolute -inset-2 bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 rounded-full opacity-20 animate-pulse-slow"></div>
              
              {/* Profile image with background removal effect */}
              <motion.div
                className="relative w-80 h-80 rounded-full overflow-hidden"
                whileHover={{ scale: 1.05, rotate: [0, 2, -2, 0] }}
                transition={{ duration: 0.8, type: "spring" }}
              >
                <img 
                  src={_1745305083061} 
                  alt="Kinjal Patel - UI/UX Designer" 
                  className="w-full h-full object-cover object-center relative z-10"
                  style={{
                    filter: 'drop-shadow(0 0 20px rgba(168, 85, 247, 0.3))',
                    maskImage: 'radial-gradient(circle, black 40%, transparent 70%)',
                    WebkitMaskImage: 'radial-gradient(circle, black 40%, transparent 70%)'
                  }}
                />
                
                {/* Creative border effects */}
                <div className="absolute inset-0 rounded-full border-4 border-gradient-to-r from-purple-500 to-indigo-500 shadow-2xl"></div>
                <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-500/20 via-transparent to-pink-500/20"></div>
                
                {/* Floating particles around image */}
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 bg-purple-400 rounded-full opacity-60"
                    style={{
                      top: `${20 + (i * 15)}%`,
                      left: `${10 + (i * 12)}%`,
                    }}
                    animate={{
                      y: [0, -20, 0],
                      opacity: [0.3, 0.8, 0.3],
                    }}
                    transition={{
                      duration: 3,
                      delay: i * 0.3,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  />
                ))}
              </motion.div>
            </div>
          </motion.div>

          {/* Content - Right Side */}
          <motion.div 
            className="lg:w-1/2 text-center lg:text-left"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.h1 
              className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <span className="block text-gray-200 mb-2">Hi, I'm</span>
              <span className="block gradient-text animate-pulse">
                Kinjal Patel
              </span>
            </motion.h1>
            
            <motion.p 
              className="text-xl sm:text-2xl text-gray-300 mb-6 font-light"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              UI/UX & Graphics Designer
            </motion.p>
            
            <motion.p 
              className="text-lg text-gray-400 mb-8 max-w-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              With 5+ years of experience creating exceptional digital experiences through 
              innovative design solutions that blend creativity with functionality.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1 }}
            >
              <button
                onClick={() => handleCTAClick('portfolio')}
                className="px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-medium rounded-full hover:from-pink-600 hover:to-purple-600 hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-purple-500/25"
              >
                View My Work
              </button>
              <button
                onClick={() => handleCTAClick('contact')}
                className="px-8 py-4 border-2 border-purple-500 text-purple-400 font-medium rounded-full hover:bg-purple-500 hover:text-white hover:scale-105 transition-all duration-300"
              >
                Get In Touch
              </button>
            </motion.div>
          </motion.div>
        </div>
      </div>
      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <ArrowDown className="w-6 h-6 text-gray-400" />
      </motion.div>
    </section>
  );
};

export default Hero;
