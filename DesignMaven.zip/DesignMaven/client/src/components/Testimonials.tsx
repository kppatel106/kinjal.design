import { motion } from 'framer-motion';
import { Star, ExternalLink } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'CEO, TechFlow Solutions',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150',
      content: "Kinjal delivered an exceptional UI/UX design for our mobile app. Her attention to detail and understanding of user needs resulted in a 40% increase in user engagement. Highly recommended!",
      rating: 5,
      borderColor: 'border-purple-500'
    },
    {
      name: 'Michael Chen',
      role: 'Founder, Creative Studios',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150',
      content: "Working with Kinjal was a game-changer for our brand identity. Her creative vision and professional execution helped us stand out in a competitive market. The entire team was impressed!",
      rating: 5,
      borderColor: 'border-indigo-500'
    }
  ];

  const StarRating = ({ rating }: { rating: number }) => (
    <div className="flex space-x-1 mb-4">
      {Array.from({ length: 5 }, (_, i) => (
        <Star 
          key={i} 
          className={`w-5 h-5 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} 
        />
      ))}
    </div>
  );

  return (
    <section id="testimonials" className="relative py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-4 gradient-text">
            What Clients Say
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-indigo-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              className={`group bg-gray-900/50 p-8 rounded-2xl border ${testimonial.borderColor} hover:border-purple-400 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25`}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-6">
                <div className="relative">
                  <img 
                    src={testimonial.image}
                    alt={`${testimonial.name} testimonial`}
                    className={`w-16 h-16 rounded-full object-cover border-2 ${testimonial.borderColor}`}
                  />
                  <motion.div 
                    className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center"
                    whileHover={{ scale: 1.1 }}
                  >
                    <ExternalLink className="w-3 h-3 text-white" />
                  </motion.div>
                </div>
                <div className="ml-4">
                  <h4 className="text-white font-semibold">{testimonial.name}</h4>
                  <p className="text-purple-400 text-sm">{testimonial.role}</p>
                </div>
              </div>
              
              <StarRating rating={testimonial.rating} />
              
              <motion.p 
                className="text-gray-300 text-lg leading-relaxed"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.2 + 0.3 }}
                viewport={{ once: true }}
              >
                "{testimonial.content}"
              </motion.p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
