import { motion } from 'framer-motion';
import { useSkillBarAnimation } from '@/hooks/useScrollAnimation';
import { formatPercentage } from '@/lib/utils';

const Skills = () => {
  const { isVisible, elementRef } = useSkillBarAnimation();

  const designTools = [
    { name: 'Figma', percentage: 95, color: 'from-purple-500 to-indigo-500' },
    { name: 'Adobe Photoshop', percentage: 90, color: 'from-purple-500 to-pink-500' },
    { name: 'Adobe Illustrator', percentage: 88, color: 'from-indigo-500 to-purple-500' },
    { name: 'Sketch', percentage: 80, color: 'from-orange-500 to-red-500' },
  ];

  const creativeSoftware = [
    { name: 'After Effects', percentage: 85, color: 'from-pink-500 to-purple-500' },
    { name: 'Premiere Pro', percentage: 82, color: 'from-indigo-500 to-pink-500' },
    { name: 'Canva', percentage: 92, color: 'from-purple-500 to-indigo-500' },
    { name: 'Photoshop', percentage: 87, color: 'from-blue-500 to-purple-500' },
  ];

  const developmentTools = [
    { name: 'HTML/CSS', percentage: 78, color: 'from-green-500 to-blue-500' },
    { name: 'JavaScript', percentage: 65, color: 'from-yellow-500 to-orange-500' },
    { name: 'WordPress', percentage: 75, color: 'from-blue-600 to-indigo-600' },
  ];

  const tools = [
    { name: 'Figma', icon: '🎨', gradient: 'from-purple-500 to-indigo-500', hoverGradient: 'from-purple-600 to-indigo-600' },
    { name: 'Photoshop', icon: '🖼️', gradient: 'from-blue-500 to-purple-500', hoverGradient: 'from-blue-600 to-purple-600' },
    { name: 'Illustrator', icon: '✏️', gradient: 'from-orange-500 to-red-500', hoverGradient: 'from-orange-600 to-red-600' },
    { name: 'After Effects', icon: '🎬', gradient: 'from-purple-500 to-pink-500', hoverGradient: 'from-purple-600 to-pink-600' },
    { name: 'Premiere Pro', icon: '📹', gradient: 'from-indigo-500 to-purple-500', hoverGradient: 'from-indigo-600 to-purple-600' },
    { name: 'Canva', icon: '🎯', gradient: 'from-green-500 to-blue-500', hoverGradient: 'from-green-600 to-blue-600' },
    { name: 'Sketch', icon: '📐', gradient: 'from-yellow-500 to-orange-500', hoverGradient: 'from-yellow-600 to-orange-600' },
    { name: 'InVision', icon: '💡', gradient: 'from-pink-500 to-purple-500', hoverGradient: 'from-pink-600 to-purple-600' },
  ];

  const SkillBar = ({ skill, delay = 0 }: { skill: typeof designTools[0], delay?: number }) => (
    <motion.div 
      className="space-y-2"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      viewport={{ once: true }}
    >
      <div className="flex justify-between items-center">
        <span className="text-gray-300 font-medium">{skill.name}</span>
        <span className="text-purple-400 font-semibold">{formatPercentage(skill.percentage)}</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-3">
        <motion.div 
          className={`bg-gradient-to-r ${skill.color} h-3 rounded-full`}
          initial={{ width: 0 }}
          whileInView={{ width: `${skill.percentage}%` }}
          transition={{ duration: 1.5, delay: delay + 0.5, ease: "easeInOut" }}
          viewport={{ once: true }}
        />
      </div>
    </motion.div>
  );

  return (
    <section id="skills" className="relative py-20" ref={elementRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-4 gradient-text">
            Skills & Tools
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-indigo-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Design Tools */}
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Design Tools</h3>
            {designTools.map((skill, index) => (
              <SkillBar key={skill.name} skill={skill} delay={index * 0.2} />
            ))}
          </div>

          {/* Creative Software */}
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Creative Software</h3>
            {creativeSoftware.map((skill, index) => (
              <SkillBar key={skill.name} skill={skill} delay={index * 0.2} />
            ))}
          </div>

          {/* Development Skills */}
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Development</h3>
            {developmentTools.map((skill, index) => (
              <SkillBar key={skill.name} skill={skill} delay={index * 0.2} />
            ))}
          </div>
        </div>

        {/* Tool Icons */}
        <motion.div 
          className="mt-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-semibold text-white mb-8 text-center">Tools I Use</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-6">
            {tools.map((tool, index) => (
              <motion.div 
                key={tool.name}
                className="flex flex-col items-center space-y-3 group cursor-pointer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ 
                  scale: 1.15,
                  y: -5,
                  transition: { duration: 0.3, type: "spring", stiffness: 300 }
                }}
              >
                <motion.div 
                  className={`w-16 h-16 bg-gradient-to-br ${tool.gradient} rounded-xl flex items-center justify-center shadow-lg`}
                  whileHover={{ 
                    boxShadow: "0 20px 40px rgba(168, 85, 247, 0.3)",
                    rotate: [0, -10, 10, -10, 0],
                    transition: { duration: 0.5 }
                  }}
                  whileTap={{ scale: 0.95 }}
                >
                  <motion.span 
                    className="text-2xl"
                    whileHover={{ 
                      scale: 1.1,
                      transition: { duration: 0.2 }
                    }}
                  >
                    {tool.icon}
                  </motion.span>
                </motion.div>
                <motion.span 
                  className="text-sm text-gray-400 group-hover:text-white transition-colors duration-300 font-medium"
                  whileHover={{ scale: 1.05 }}
                >
                  {tool.name}
                </motion.span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
