import { motion } from 'framer-motion';
import { Mail, Instagram, ExternalLink } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: Mail, href: 'mailto:kinjal@example.com', hoverColor: 'hover:text-purple-400' },
    { icon: Instagram, href: 'https://instagram.com/kinjalpatel', hoverColor: 'hover:text-pink-400' },
    { icon: ExternalLink, href: 'https://behance.net/kinjalpatel', hoverColor: 'hover:text-blue-400' },
  ];

  return (
    <footer className="relative py-12 bg-gray-900 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="mb-6">
            <span className="text-2xl font-bold gradient-text">
              Kinjal Patel
            </span>
          </div>
          
          <motion.p 
            className="text-gray-400 mb-6 max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Thank you for visiting my portfolio. I'm excited to collaborate with you and bring your creative vision to life through exceptional design.
          </motion.p>
          
          <motion.div 
            className="flex justify-center space-x-6 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`text-gray-400 ${link.hoverColor} transition-colors`}
                whileHover={{ scale: 1.2, y: -2 }}
                whileTap={{ scale: 0.9 }}
              >
                <link.icon className="w-6 h-6" />
              </motion.a>
            ))}
          </motion.div>
          
          <motion.p 
            className="text-gray-500 text-sm"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            © 2024 Kinjal Patel. All rights reserved. Designed with passion and creativity.
          </motion.p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
