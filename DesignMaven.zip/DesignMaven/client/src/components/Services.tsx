import { motion } from 'framer-motion';
import { Monitor, Smartphone, Palette, Share2, Video, TrendingUp, Check } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Monitor,
      title: 'Website Design',
      description: 'Creating responsive and user-friendly websites that convert visitors into customers.',
      features: [
        'Responsive Design',
        'User Experience Optimization',
        'Modern UI Components',
        'Cross-browser Compatibility'
      ]
    },
    {
      icon: Smartphone,
      title: 'Mobile App Design',
      description: 'Designing intuitive mobile interfaces that provide seamless user experiences.',
      features: [
        'iOS & Android Design',
        'Wireframing & Prototyping',
        'User Flow Optimization',
        'Interactive Animations'
      ]
    },
    {
      icon: Palette,
      title: 'Brand Identity',
      description: 'Developing comprehensive brand identities that tell your unique story.',
      features: [
        'Logo Design',
        'Brand Guidelines',
        'Color Palette Creation',
        'Typography Selection'
      ]
    },
    {
      icon: Share2,
      title: 'Social Media Graphics',
      description: 'Creating engaging visual content that drives social media engagement.',
      features: [
        'Social Media Templates',
        'Content Strategy',
        'Platform Optimization',
        'Engagement Analytics'
      ]
    },
    {
      icon: Video,
      title: 'Video Production',
      description: 'Producing high-quality videos that captivate and convert your audience.',
      features: [
        'Motion Graphics',
        'Video Editing',
        'Animation Design',
        'Sound Design'
      ]
    },
    {
      icon: TrendingUp,
      title: 'UX Research',
      description: 'Conducting user research to create data-driven design decisions.',
      features: [
        'User Testing',
        'Analytics Review',
        'Competitor Analysis',
        'Design Strategy'
      ]
    }
  ];

  return (
    <section id="services" className="relative py-20 bg-gray-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-4 gradient-text">
            My Services
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-indigo-500 mx-auto rounded-full"></div>
          <p className="text-gray-400 mt-6 max-w-2xl mx-auto">
            I offer comprehensive design services to help your business stand out and succeed in the digital landscape.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              className="group relative bg-gray-900/50 p-8 rounded-2xl border border-gray-700 hover:border-purple-500 transition-all duration-300 hover:scale-103 hover:shadow-2xl hover:shadow-purple-500/25"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <div className="text-center mb-6">
                <motion.div 
                  className="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300"
                  whileHover={{ 
                    rotate: [0, -10, 10, -10, 0],
                    transition: { duration: 0.5 }
                  }}
                >
                  <service.icon className="w-8 h-8 text-white" />
                </motion.div>
                <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                <p className="text-gray-400 leading-relaxed">{service.description}</p>
              </div>

              <div className="space-y-3">
                {service.features.map((feature, featureIndex) => (
                  <motion.div 
                    key={feature}
                    className="flex items-center space-x-3"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 + featureIndex * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{feature}</span>
                  </motion.div>
                ))}
              </div>

              <motion.div 
                className="mt-6 pt-6 border-t border-gray-700"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 + 0.5 }}
                viewport={{ once: true }}
              >
                <button 
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-medium rounded-lg hover:from-pink-600 hover:to-purple-600 hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-purple-500/25"
                >
                  Get Started
                </button>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
