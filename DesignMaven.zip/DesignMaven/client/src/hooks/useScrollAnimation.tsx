import { useEffect, useRef, useState } from 'react';

interface UseScrollAnimationOptions {
  threshold?: number;
  rootMargin?: string;
  triggerOnce?: boolean;
}

export function useScrollAnimation(options: UseScrollAnimationOptions = {}) {
  const {
    threshold = 0.3,
    rootMargin = '0px 0px -50px 0px',
    triggerOnce = true
  } = options;

  const [isVisible, setIsVisible] = useState(false);
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          if (triggerOnce) {
            observer.unobserve(element);
          }
        } else if (!triggerOnce) {
          setIsVisible(false);
        }
      },
      { threshold, rootMargin }
    );

    observer.observe(element);

    return () => {
      observer.unobserve(element);
    };
  }, [threshold, rootMargin, triggerOnce]);

  return { isVisible, elementRef };
}

export function useSkillBarAnimation() {
  const { isVisible, elementRef } = useScrollAnimation();
  const [animatedBars, setAnimatedBars] = useState<Set<string>>(new Set());

  const animateSkillBar = (skillName: string, percentage: number) => {
    if (isVisible && !animatedBars.has(skillName)) {
      setAnimatedBars(prev => new Set(prev).add(skillName));
      return true;
    }
    return false;
  };

  return { isVisible, elementRef, animateSkillBar, animatedBars };
}
